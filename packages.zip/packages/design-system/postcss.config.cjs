module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-nesting': {},
    autoprefixer: {},
    cssnano: { preset: 'default' }
  }
};
