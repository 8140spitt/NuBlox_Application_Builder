import mysql, { Pool } from 'mysql2/promise';
import { PoolConnection, RowDataPacket, ResultSetHeader } from 'mysql2';

export type DB = ReturnType<typeof createDB>;
export type { PoolConnection, RowDataPacket, ResultSetHeader };

export function createDB(env = process.env) {
  const pool: Pool = mysql.createPool({
    host: env.DB_HOST!, port: Number(env.DB_PORT || 3306), user: env.DB_USER!, password: env.DB_PASS!, database: env.DB_NAME!,
    waitForConnections: true, connectionLimit: 10, enableKeepAlive: true
  });

  const query = async <T = any>(sql: string, params?: any[]): Promise<T[]> => {
    const [rows] = await pool.query(sql, params);
    return rows as T[];
  };

  const exec = async (sql: string, params?: any[]) => { await pool.execute(sql, params); };

  const tx = async <T>(fn: (conn: PoolConnection) => Promise<T>) => {
    const conn = await pool.getConnection();
    try { await conn.beginTransaction(); const out = await fn(conn); await conn.commit(); return out; }
    catch (e) { await conn.rollback(); throw e; }
    finally { conn.release(); }
  };

  return { pool, query, exec, tx };
}
