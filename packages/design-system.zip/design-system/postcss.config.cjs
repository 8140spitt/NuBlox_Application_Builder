// CommonJS config (works regardless of "type": "module")
module.exports = {
    map: false,
    plugins: {
        'postcss-import': {},
        'postcss-nesting': {},
        autoprefixer: {}
    }
};
