import { writeFileSync, mkdirSync, readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildThemeQuick, toCssTokens, toJsonTokens } from '../src/palettes/palettes-multibrand';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const root = resolve(__dirname, '..');

// Try to infer base brand hexes from existing tokens.css fallbacks
function inferHexes(tokensCss: string): string[] {
  const m = tokensCss.match(/--nublox-(primary|secondary|tertiary|quaternary):\\s*(#[0-9a-fA-F]{3,6})/g) || [];
  const ordered = ['primary','secondary','tertiary','quaternary'].map(role => {
    const r = new RegExp(`--nublox-${role}:\\s*(#[0-9a-fA-F]{3,6})`,'i');
    const mm = tokensCss.match(r);
    return mm ? mm[1] : null;
  }).filter(Boolean) as string[];
  if (ordered.length) return ordered;
  return ['#a65de9','#47a4ff','#47ffd7','#fba94c'];
}

const srcTokensCssPath = resolve(root, 'src/css/tokens.css');
let baseCss = '';
try { baseCss = readFileSync(srcTokensCssPath, 'utf8'); } catch {}

const hexes = inferHexes(baseCss);
const theme = buildThemeQuick(hexes);

const distDir = resolve(root, 'dist');
mkdirSync(distDir, { recursive: true });

// Write dist/tokens.css and dist/tokens.json for consumers
writeFileSync(resolve(distDir, 'tokens.css'), toCssTokens(theme, { includeComments: true }), 'utf8');
writeFileSync(resolve(distDir, 'tokens.json'), JSON.stringify(toJsonTokens(theme), null, 2), 'utf8');

// Also refresh src/css/tokens.css so postcss build picks up latest tokens within @layer
const wrapped = `@layer tokens {\n${toCssTokens(theme)}\n}\n`;
writeFileSync(srcTokensCssPath, wrapped, 'utf8');

console.log('✅ Generated tokens from', hexes.join(', '));
