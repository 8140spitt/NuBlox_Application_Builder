// palettes.ts
// NuBlox-style hybrid palette generator (contrast-first, Spectrum-inspired)

type HSL = { h: number; s: number; l: number };
type Swatch = { step: number; hex: string; hsl: HSL; on: "#000000" | "#FFFFFF"; crWhite: number; crBlack: number };
type Ramp = Record<50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950, Swatch>;
type Palette = {
    primary: Ramp;
    neutral: Ramp;
    success: Ramp;
    warning: Ramp;
    danger: Ramp;
    info: Ramp;
    // CSS tokens ready to output
    tokens: {
        light: string;
        dark: string;
    }
};

// ---------- Color math (no deps) ----------
function clamp(n: number, min = 0, max = 1) { return Math.min(max, Math.max(min, n)); }
function hexToRgb(hex: string): { r: number; g: number; b: number } {
    const s = hex.replace("#", "").trim();
    const n = s.length === 3 ? s.split("").map(ch => ch + ch).join("") : s;
    const x = parseInt(n, 16);
    return { r: (x >> 16) & 255, g: (x >> 8) & 255, b: x & 255 };
}
function rgbToHex(r: number, g: number, b: number) {
    const to = (v: number) => v.toString(16).padStart(2, "0");
    return `#${to(Math.round(r))}${to(Math.round(g))}${to(Math.round(b))}`.toLowerCase();
}
function rgbToHsl(r: number, g: number, b: number): HSL {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            default: h = (r - g) / d + 4;
        }
        h *= 60;
    }
    return { h: (h + 360) % 360, s: s * 100, l: l * 100 };
}
function hslToRgb(h: number, s: number, l: number) {
    h = (h % 360 + 360) % 360; s /= 100; l /= 100;
    const c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
    let r = 0, g = 0, b = 0;
    if (h < 60) { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else { r = c; g = 0; b = x; }
    return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
}
function hslToHex(h: number, s: number, l: number) {
    const { r, g, b } = hslToRgb(h, s, l);
    return rgbToHex(r, g, b);
}
// WCAG 2.x relative luminance + contrast
function srgbToLin(v: number) { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
function luminance(hex: string) {
    const { r, g, b } = hexToRgb(hex);
    const R = srgbToLin(r), G = srgbToLin(g), B = srgbToLin(b);
    return 0.2126 * R + 0.7152 * G + 0.0722 * B;
}
function contrastRatio(hex1: string, hex2: string) {
    const L1 = luminance(hex1), L2 = luminance(hex2);
    const [hi, lo] = L1 > L2 ? [L1, L2] : [L2, L1];
    return (hi + 0.05) / (lo + 0.05);
}
// pick readable foreground
function onColor(bgHex: string, min = 4.5): "#000000" | "#FFFFFF" {
    const cW = contrastRatio(bgHex, "#ffffff");
    const cB = contrastRatio(bgHex, "#000000");
    if (cW >= min && cW >= cB) return "#FFFFFF";
    if (cB >= min) return "#000000";
    // fallback to the better of the two if both fail (rare at mid tones)
    return cW >= cB ? "#FFFFFF" : "#000000";
}

// ---------- Ramp generation ----------
const STEPS = [50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950] as const;
function easeInOut(t: number) { // smoother lightness distribution (perceptually nicer than linear)
    return 0.5 * (1 - Math.cos(Math.PI * t));
}
/** Build a tonal ramp: lock hue, taper saturation near extremes, spread lightness 96→9 */
function buildRamp(h: number, baseS: number, opts?: { sMin?: number; sMax?: number; lHi?: number; lLo?: number }): Ramp {
    const sMin = opts?.sMin ?? 6;   // minimal saturation at the ends
    const sMax = opts?.sMax ?? Math.min(92, baseS);
    const lHi = opts?.lHi ?? 96;  // lightest
    const lLo = opts?.lLo ?? 9;   // darkest

    const entries = STEPS.map((step, i) => {
        const t = i / (STEPS.length - 1);
        // L spread with easing
        const l = lHi - (lHi - lLo) * easeInOut(t);
        // Saturation taper: strongest in middle, softer at extremes
        const midBoost = 1 - Math.abs(0.5 - t) * 2; // 0..1 peaking at middle
        const s = clamp((sMin + (sMax - sMin) * (0.6 + 0.4 * midBoost)) / 100, 0, 1) * 100;

        const hex = hslToHex(h, s, l);
        const crW = contrastRatio(hex, "#ffffff");
        const crB = contrastRatio(hex, "#000000");
        const on = onColor(hex, 4.5);
        return [step, { step, hex, hsl: { h, s, l }, on, crWhite: crW, crBlack: crB }] as const;
    });

    return Object.fromEntries(entries) as Ramp;
}

// ---------- Semantic sets (brand-tunable hues) ----------
const STATUS = {
    success: 145,   // green
    warning: 38,    // orange/amber
    danger: 4,      // red
    info: 210       // cobalt-ish blue
};

function paletteFromBase(baseHex: string): Palette {
    const { h, s } = rgbToHsl(...Object.values(hexToRgb(baseHex)));
    const baseS = s;

    // primary from base hue
    const primary = buildRamp(h, baseS);

    // neutral gray ramp (stable hue 240, very low sat)
    const neutral = buildRamp(240, 10, { sMin: 4, sMax: 10 });

    // status ramps
    const success = buildRamp(STATUS.success, 60);
    const warning = buildRamp(STATUS.warning, 70);
    const danger = buildRamp(STATUS.danger, 70);
    const info = buildRamp(STATUS.info, 65);

    // CSS tokens: light = normal mapping, dark = inverted mapping (surface bias)
    const mapTokens = (r: Ramp, prefix: string, invert = false) => {
        const steps = invert ? [...STEPS].reverse() : [...STEPS];
        const pairs = steps.map((step, i) => {
            const sw = r[STEPS[i]];           // align by index
            return `  --${prefix}-${step}: ${sw.hex};\n  --on-${prefix}-${step}: ${sw.on};`;
        }).join("\n");
        return pairs;
    };

    const light = [
        ":root, [data-theme='light'] {",
        mapTokens(primary, "color-primary"),
        mapTokens(neutral, "color-neutral"),
        mapTokens(success, "color-success"),
        mapTokens(warning, "color-warning"),
        mapTokens(danger, "color-danger"),
        mapTokens(info, "color-info"),
        "}"
    ].join("\n");

    const dark = [
        "[data-theme='dark'] {",
        mapTokens(primary, "color-primary", true),
        mapTokens(neutral, "color-neutral", true),
        mapTokens(success, "color-success", true),
        mapTokens(warning, "color-warning", true),
        mapTokens(danger, "color-danger", true),
        mapTokens(info, "color-info", true),
        "}"
    ].join("\n");

    return { primary, neutral, success, warning, danger, info, tokens: { light, dark } };
}

// ---------- Helper to pick best accessible step for a role (e.g., buttons) ----------
export function pickForRole(ramp: Ramp, target: "bg" | "surface" | "accent" | "muted" = "accent") {
    // Simple sensible defaults; tweak per system:
    const candidates: Record<typeof target, (keyof Ramp)[]> = {
        bg: [50, 100, 200, 300] as any,
        surface: [100, 200, 300, 400] as any,
        accent: [500, 600, 700] as any,
        muted: [200, 300, 400, 500] as any,
    };
    for (const step of candidates[target]) {
        const sw = ramp[step];
        if (contrastRatio(sw.hex, sw.on) >= 4.5) return sw;
    }
    // Fallback to the most contrasting in the ramp
    const arr = (Object.values(ramp) as Swatch[]).map(s => ({ s, cr: contrastRatio(s.hex, s.on) }));
    arr.sort((a, b) => b.cr - a.cr);
    return arr[0].s;
}

export function buildPalettes(baseHex: string): Palette {
    return paletteFromBase(baseHex);
}
